# Keep TFLite classes
-keep class org.tensorflow.** { *; }
-keep class com.google.flatbuffers.** { *; }

# Keep Room entities
-keep class com.offlinepal.notes.Note { *; }
-keep class com.offlinepal.todo.TodoItem { *; }
-keep class com.offlinepal.quiz.QuizCard { *; }

# Keep data classes
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# Kotlin serialization
-keepattributes *Annotation*
-keepclassmembers class ** {
    @org.jetbrains.annotations.* *;
}
