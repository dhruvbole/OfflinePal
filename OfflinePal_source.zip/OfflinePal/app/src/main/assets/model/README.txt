MOBILBERT MODEL SETUP
=====================

The on-device AI assistant uses the MobileBERT Q&A model from TensorFlow Hub.
You must download it once before building. The model file is ~25 MB.

AUTOMATIC (recommended)
------------------------
Run this from the project root:

  chmod +x download_model.sh
  ./download_model.sh

MANUAL
------
1. Open this URL in a browser:
   https://tfhub.dev/tensorflow/lite-model/mobilebert/1/metadata/1?lite-format=tflite

2. Click "Download" — you get a file called "lite-model_mobilebert_1_metadata_1.tflite"

3. Rename it to:
   mobilebert.tflite

4. Place it at:
   app/src/main/assets/model/mobilebert.tflite

5. Build the project normally.

NOTE: If the model file is absent, the AI assistant automatically falls back
to its built-in offline knowledge base — it still works fully offline, just
without neural Q&A for contextual questions.
