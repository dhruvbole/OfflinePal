package com.offlinepal.quiz

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.offlinepal.AppDatabase
import kotlinx.coroutines.launch

class QuizViewModel(application: Application) : AndroidViewModel(application) {

    private val dao: QuizDao = AppDatabase.getDatabase(application).quizDao()

    val allCards: LiveData<List<QuizCard>> = dao.getAllCards().asLiveData()
    val categories: LiveData<List<String>> = dao.getCategories().asLiveData()

    // ─── Session State ────────────────────────────────────────────────────────
    private val _sessionCards = MutableLiveData<List<QuizCard>>(emptyList())
    val sessionCards: LiveData<List<QuizCard>> = _sessionCards

    private val _currentIndex = MutableLiveData(0)
    val currentIndex: LiveData<Int> = _currentIndex

    private val _isFlipped = MutableLiveData(false)
    val isFlipped: LiveData<Boolean> = _isFlipped

    private val _score = MutableLiveData(0)
    val score: LiveData<Int> = _score

    private val _sessionFinished = MutableLiveData(false)
    val sessionFinished: LiveData<Boolean> = _sessionFinished

    fun startSession(category: String? = null, count: Int = 10) {
        viewModelScope.launch {
            val cards = if (category == null) {
                dao.getRandomCards(count)
            } else {
                dao.getRandomCards(category, count)
            }
            _sessionCards.value = cards
            _currentIndex.value = 0
            _isFlipped.value = false
            _score.value = 0
            _sessionFinished.value = false
        }
    }

    fun flipCard() {
        _isFlipped.value = !(_isFlipped.value ?: false)
    }

    fun markCorrect() {
        _score.value = (_score.value ?: 0) + 1
        val card = _sessionCards.value?.getOrNull(_currentIndex.value ?: 0)
        card?.let {
            viewModelScope.launch {
                dao.update(it.copy(timesShown = it.timesShown + 1, timesCorrect = it.timesCorrect + 1))
            }
        }
        nextCard()
    }

    fun markWrong() {
        val card = _sessionCards.value?.getOrNull(_currentIndex.value ?: 0)
        card?.let {
            viewModelScope.launch {
                dao.update(it.copy(timesShown = it.timesShown + 1))
            }
        }
        nextCard()
    }

    private fun nextCard() {
        val total = _sessionCards.value?.size ?: 0
        val next = (_currentIndex.value ?: 0) + 1
        if (next >= total) {
            _sessionFinished.value = true
        } else {
            _currentIndex.value = next
            _isFlipped.value = false
        }
    }

    fun insert(card: QuizCard) = viewModelScope.launch { dao.insert(card) }
    fun delete(card: QuizCard) = viewModelScope.launch { dao.delete(card) }

    fun seedDefaultCards() = viewModelScope.launch {
        if (dao.getCount() == 0) {
            defaultCards.forEach { dao.insert(it) }
        }
    }

    private val defaultCards = listOf(
        QuizCard(question = "What is the capital of France?", answer = "Paris", category = "Geography"),
        QuizCard(question = "What is 12 × 12?", answer = "144", category = "Math"),
        QuizCard(question = "What planet is closest to the Sun?", answer = "Mercury", category = "Science"),
        QuizCard(question = "Who wrote Romeo and Juliet?", answer = "William Shakespeare", category = "Literature"),
        QuizCard(question = "In what year did World War II end?", answer = "1945", category = "History"),
        QuizCard(question = "What is the chemical symbol for gold?", answer = "Au", category = "Science"),
        QuizCard(question = "What is the largest ocean on Earth?", answer = "Pacific Ocean", category = "Geography"),
        QuizCard(question = "What is the square root of 144?", answer = "12", category = "Math"),
        QuizCard(question = "Who painted the Mona Lisa?", answer = "Leonardo da Vinci", category = "Art"),
        QuizCard(question = "What gas do plants absorb from the air?", answer = "Carbon dioxide (CO₂)", category = "Science"),
        QuizCard(question = "How many continents are there?", answer = "7", category = "Geography"),
        QuizCard(question = "What is the longest river in the world?", answer = "The Nile", category = "Geography"),
        QuizCard(question = "What is H₂O commonly known as?", answer = "Water", category = "Science"),
        QuizCard(question = "Who invented the telephone?", answer = "Alexander Graham Bell", category = "History"),
        QuizCard(question = "What is the smallest prime number?", answer = "2", category = "Math")
    )
}
