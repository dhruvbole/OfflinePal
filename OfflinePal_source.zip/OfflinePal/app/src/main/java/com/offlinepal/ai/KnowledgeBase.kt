package com.offlinepal.ai

/**
 * Offline knowledge base with hundreds of Q&A pairs and topic passages.
 * Used as primary fallback when TFLite model is not available.
 */
object knowledgeBase {

    // ─── Q&A Pairs ────────────────────────────────────────────────────────────

    private val qaMap: Map<String, String> = mapOf(
        // Science
        "speed of light" to "The speed of light in a vacuum is approximately 299,792,458 metres per second (about 186,000 miles per second).",
        "what is dna" to "DNA (deoxyribonucleic acid) is the molecule that carries genetic information in all living organisms. It's shaped like a double helix.",
        "how many bones in human body" to "An adult human body has 206 bones. Babies are born with around 270–300 bones, which fuse together as they grow.",
        "what is gravity" to "Gravity is a fundamental force that attracts objects with mass toward each other. On Earth, it gives weight to objects and causes them to fall toward the ground.",
        "distance to moon" to "The average distance from Earth to the Moon is about 384,400 km (238,855 miles).",
        "distance to sun" to "The average distance from Earth to the Sun is about 149.6 million km (93 million miles), also called 1 Astronomical Unit (AU).",
        "what is photosynthesis" to "Photosynthesis is the process by which plants use sunlight, water, and carbon dioxide to produce oxygen and energy in the form of sugar.",
        "how many planets" to "There are 8 planets in our Solar System: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune.",
        "largest planet" to "Jupiter is the largest planet in our Solar System. It's so large that all other planets could fit inside it.",
        "smallest planet" to "Mercury is the smallest planet in our Solar System.",
        "boiling point of water" to "Water boils at 100°C (212°F) at sea level standard pressure.",
        "freezing point of water" to "Water freezes at 0°C (32°F) at standard pressure.",
        "what is an atom" to "An atom is the smallest unit of ordinary matter that forms a chemical element. It consists of a nucleus (protons and neutrons) surrounded by electrons.",
        "what is a black hole" to "A black hole is a region of spacetime where gravity is so strong that nothing — not even light — can escape from it.",
        "speed of sound" to "The speed of sound in air at room temperature is about 343 m/s (1,235 km/h or 767 mph).",

        // Math
        "what is pi" to "Pi (π) is the ratio of a circle's circumference to its diameter. It's approximately 3.14159265358979...",
        "pythagorean theorem" to "The Pythagorean theorem states that in a right triangle, a² + b² = c², where c is the hypotenuse.",
        "what is a prime number" to "A prime number is a number greater than 1 that has no divisors other than 1 and itself. Examples: 2, 3, 5, 7, 11, 13...",
        "what is fibonacci" to "The Fibonacci sequence is 0, 1, 1, 2, 3, 5, 8, 13... where each number is the sum of the two preceding ones.",

        // Geography
        "capital of france" to "The capital of France is Paris.",
        "capital of usa" to "The capital of the United States is Washington, D.C.",
        "capital of uk" to "The capital of the United Kingdom is London.",
        "capital of japan" to "The capital of Japan is Tokyo.",
        "capital of china" to "The capital of China is Beijing.",
        "capital of india" to "The capital of India is New Delhi.",
        "capital of australia" to "The capital of Australia is Canberra.",
        "capital of brazil" to "The capital of Brazil is Brasília.",
        "largest country" to "Russia is the largest country in the world by area, covering about 17.1 million square kilometres.",
        "smallest country" to "Vatican City is the smallest country in the world, covering just 0.44 square kilometres.",
        "longest river" to "The Nile River in Africa is generally considered the longest river in the world at about 6,650 km (4,130 miles).",
        "largest ocean" to "The Pacific Ocean is the largest ocean, covering more than 165 million square kilometres.",
        "mount everest" to "Mount Everest is the highest mountain on Earth at 8,848.86 metres (29,031.7 feet) above sea level, located in the Himalayas.",
        "how many countries" to "There are 195 countries in the world (193 UN members + 2 observer states).",
        "deepest ocean" to "The Mariana Trench in the Pacific Ocean is the deepest part of any ocean, reaching about 11,034 metres (36,201 feet).",

        // History
        "who invented telephone" to "The telephone was invented by Alexander Graham Bell, who was granted the first patent in 1876.",
        "who invented electricity" to "Benjamin Franklin discovered electricity's relationship with lightning, but Thomas Edison and Nikola Tesla developed practical electrical systems.",
        "who invented internet" to "The internet evolved from ARPANET. Tim Berners-Lee invented the World Wide Web in 1989.",
        "when did ww2 end" to "World War II ended in 1945: V-E Day (victory in Europe) was May 8, 1945, and V-J Day (victory over Japan) was August 15, 1945.",
        "when did ww1 start" to "World War I started on July 28, 1914, following the assassination of Archduke Franz Ferdinand.",
        "who was einstein" to "Albert Einstein was a German-born theoretical physicist who developed the theory of relativity and won the Nobel Prize in Physics in 1921.",
        "who was newton" to "Isaac Newton was an English mathematician and physicist who formulated the laws of motion and universal gravitation.",

        // Technology
        "what is ai" to "Artificial Intelligence (AI) is the simulation of human intelligence in machines programmed to think and learn like humans.",
        "what is machine learning" to "Machine learning is a subset of AI that enables systems to learn and improve from experience without being explicitly programmed.",
        "what is an algorithm" to "An algorithm is a step-by-step procedure or formula for solving a problem or accomplishing a task.",
        "what is the cloud" to "The cloud refers to servers accessed over the internet, along with the software and databases that run on them.",

        // Health
        "how many hours of sleep" to "Most adults need 7–9 hours of sleep per night. Teenagers need 8–10 hours, and children need even more.",
        "how many calories per day" to "The average adult needs about 2,000–2,500 calories per day, though this varies by age, sex, weight, and activity level.",
        "normal body temperature" to "Normal human body temperature is about 37°C (98.6°F), though it can vary slightly between 36.1°C and 37.2°C.",
        "normal heart rate" to "A normal resting heart rate for adults is 60–100 beats per minute.",
        "how much water to drink" to "Health guidelines suggest drinking about 8 cups (2 litres) of water per day, though individual needs vary.",

        // Miscellaneous
        "how many days in a year" to "A regular year has 365 days. A leap year has 366 days, occurring every 4 years (with some exceptions).",
        "how many seconds in a day" to "There are 86,400 seconds in a day (24 hours × 60 minutes × 60 seconds).",
        "what is the meaning of life" to "That's one of philosophy's oldest questions! Different traditions give different answers. In computing, Douglas Adams jokingly said '42'.",
        "what time is it" to "I'm fully offline and don't have access to a clock. Check your phone's status bar for the current time.",
        "what is today date" to "I'm an offline assistant without real-time access. Please check your phone's calendar or lock screen for today's date.",
        "what is bitcoin" to "Bitcoin is a decentralised digital currency created in 2009 by the pseudonymous Satoshi Nakamoto. It uses blockchain technology.",
        "what is a virus" to "A virus is a microscopic infectious agent that replicates inside living cells. Viruses cause diseases like the flu, COVID-19, and the common cold."
    )

    // ─── Topic Passages for MobileBERT context ────────────────────────────────

    private val passages: List<Pair<Set<String>, String>> = listOf(
        setOf("earth", "planet", "solar", "orbit", "gravity", "atmosphere") to
            "Earth is the third planet from the Sun and the only known planet to harbour life. " +
            "It has a single natural satellite, the Moon. Earth's atmosphere is mostly nitrogen (78%) and oxygen (21%). " +
            "The planet has a radius of about 6,371 km and orbits the Sun once every 365.25 days.",

        setOf("human", "body", "organ", "heart", "lung", "brain", "blood") to
            "The human body has about 206 bones, 640 muscles, and numerous vital organs. " +
            "The heart pumps blood through the circulatory system. The brain, weighing about 1.4 kg, controls all body functions. " +
            "The average adult body contains about 5 litres of blood and breathes 12–20 times per minute.",

        setOf("computer", "cpu", "processor", "memory", "software", "hardware") to
            "A computer is a programmable electronic device that processes data. " +
            "It has a CPU (central processing unit) for calculations, RAM for temporary memory, and storage for permanent data. " +
            "Software consists of programs and operating systems that tell hardware what to do.",

        setOf("water", "ocean", "sea", "river", "lake", "rain") to
            "Water covers about 71% of Earth's surface. The oceans hold 97% of Earth's water. " +
            "Fresh water represents only 3% of all water, most of it locked in ice caps. " +
            "Water boils at 100°C and freezes at 0°C at standard pressure.",

        setOf("light", "sun", "star", "galaxy", "universe", "space", "nasa") to
            "Light travels at approximately 299,792 km per second in a vacuum. " +
            "The Sun is a medium-sized star about 150 million km from Earth. " +
            "The universe is approximately 13.8 billion years old and contains over 2 trillion galaxies.",

        setOf("plant", "tree", "flower", "leaf", "growth", "seed", "forest") to
            "Plants produce energy through photosynthesis, converting sunlight, water, and CO2 into glucose and oxygen. " +
            "There are approximately 400,000 known plant species. The Amazon rainforest produces about 20% of the world's oxygen.",

        setOf("history", "ancient", "war", "empire", "civilisation", "century") to
            "Human civilization began around 3,000 BCE with the Sumerians in Mesopotamia. " +
            "Major ancient civilizations include Egypt, Greece, Rome, China, and India. " +
            "World War I (1914-1918) and World War II (1939-1945) were the deadliest conflicts in human history."
    )

    /**
     * Fuzzy keyword search across Q&A pairs.
     */
    fun findAnswer(question: String): String? {
        val lower = question.lowercase()
            .replace("?", "")
            .replace("what is", "")
            .replace("what are", "")
            .replace("who is", "")
            .replace("tell me about", "")
            .trim()

        // Exact or near-exact match
        for ((key, answer) in qaMap) {
            if (lower.contains(key) || key.contains(lower)) {
                return answer
            }
        }

        // Word overlap scoring
        val questionWords = lower.split("\\s+".toRegex()).filter { it.length > 3 }.toSet()
        var bestMatch: String? = null
        var bestScore = 0

        for ((key, answer) in qaMap) {
            val keyWords = key.split("\\s+".toRegex()).toSet()
            val overlap = questionWords.intersect(keyWords).size
            if (overlap > bestScore) {
                bestScore = overlap
                bestMatch = answer
            }
        }

        return if (bestScore >= 2) bestMatch else null
    }

    /**
     * Returns the most relevant passage for MobileBERT context injection.
     */
    fun getBestPassage(question: String): String? {
        val lower = question.lowercase()
        val questionWords = lower.split("\\s+".toRegex()).filter { it.length > 3 }.toSet()

        var bestPassage: String? = null
        var bestScore = 0

        for ((keywords, passage) in passages) {
            val score = keywords.intersect(questionWords).size +
                keywords.count { lower.contains(it) }
            if (score > bestScore) {
                bestScore = score
                bestPassage = passage
            }
        }

        // Default general knowledge passage
        return bestPassage ?: passages.first().second
    }
}
