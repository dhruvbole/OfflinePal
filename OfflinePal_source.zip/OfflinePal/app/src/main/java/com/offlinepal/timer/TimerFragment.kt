package com.offlinepal.timer

import android.content.*
import android.os.Bundle
import android.os.IBinder
import android.view.*
import androidx.fragment.app.Fragment
import com.offlinepal.databinding.FragmentTimerBinding

class TimerFragment : Fragment() {

    private var _binding: FragmentTimerBinding? = null
    private val binding get() = _binding!!

    private var timerService: TimerService? = null
    private var isBound = false
    private var isStopwatchMode = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            timerService = (binder as TimerService.TimerBinder).getService()
            isBound = true
        }
        override fun onServiceDisconnected(name: ComponentName) {
            isBound = false
        }
    }

    private val tickReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val ms = intent.getLongExtra(TimerService.EXTRA_REMAINING_MS, 0L)
            val running = intent.getBooleanExtra(TimerService.EXTRA_IS_RUNNING, false)
            updateDisplay(ms, running)
        }
    }

    private val finishReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            onTimerFinished()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTimerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupTimerPresets()
        setupControls()

        binding.tabTimer.setOnClickListener {
            isStopwatchMode = false
            binding.layoutTimerInput.visibility = View.VISIBLE
            binding.textStopwatchLabel.visibility = View.GONE
            binding.textTimerDisplay.text = "00:00"
        }

        binding.tabStopwatch.setOnClickListener {
            isStopwatchMode = true
            binding.layoutTimerInput.visibility = View.GONE
            binding.textStopwatchLabel.visibility = View.VISIBLE
            binding.textTimerDisplay.text = "00:00"
        }
    }

    private fun setupTimerPresets() {
        val presets = listOf(
            binding.preset1m to 60_000L,
            binding.preset5m to 300_000L,
            binding.preset10m to 600_000L,
            binding.preset25m to 1_500_000L,
            binding.preset30m to 1_800_000L,
            binding.preset60m to 3_600_000L
        )

        presets.forEach { (btn, ms) ->
            btn.setOnClickListener {
                setTimerDuration(ms)
            }
        }
    }

    private fun setTimerDuration(ms: Long) {
        val totalSeconds = ms / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        if (hours > 0) binding.editHours.setText(hours.toString())
        binding.editMinutes.setText(minutes.toString())
        binding.editSeconds.setText(seconds.toString())
        updateDisplayFromInput()
    }

    private fun updateDisplayFromInput() {
        val h = binding.editHours.text.toString().toLongOrNull() ?: 0L
        val m = binding.editMinutes.text.toString().toLongOrNull() ?: 0L
        val s = binding.editSeconds.text.toString().toLongOrNull() ?: 0L
        val totalMs = (h * 3600 + m * 60 + s) * 1000
        binding.textTimerDisplay.text = formatTime(totalMs)
    }

    private fun setupControls() {
        binding.btnStart.setOnClickListener {
            if (isStopwatchMode) {
                startService(TimerService.ACTION_START, 0L)
            } else {
                val h = binding.editHours.text.toString().toLongOrNull() ?: 0L
                val m = binding.editMinutes.text.toString().toLongOrNull() ?: 0L
                val s = binding.editSeconds.text.toString().toLongOrNull() ?: 0L
                val totalMs = (h * 3600 + m * 60 + s) * 1000
                if (totalMs > 0) startService(TimerService.ACTION_START, totalMs)
            }
            binding.btnStart.visibility = View.GONE
            binding.btnPause.visibility = View.VISIBLE
            binding.btnStop.visibility = View.VISIBLE
        }

        binding.btnPause.setOnClickListener {
            startService(TimerService.ACTION_PAUSE, 0L)
            binding.btnPause.visibility = View.GONE
            binding.btnResume.visibility = View.VISIBLE
        }

        binding.btnResume.setOnClickListener {
            timerService?.resumeTimer()
            binding.btnResume.visibility = View.GONE
            binding.btnPause.visibility = View.VISIBLE
        }

        binding.btnStop.setOnClickListener {
            startService(TimerService.ACTION_STOP, 0L)
            resetUI()
        }
    }

    private fun startService(action: String, durationMs: Long) {
        val intent = Intent(requireContext(), TimerService::class.java).apply {
            this.action = action
            putExtra(TimerService.EXTRA_DURATION_MS, durationMs)
        }
        requireContext().startService(intent)
        if (!isBound) {
            requireContext().bindService(
                Intent(requireContext(), TimerService::class.java),
                serviceConnection,
                Context.BIND_AUTO_CREATE
            )
        }
    }

    private fun updateDisplay(ms: Long, running: Boolean) {
        binding.textTimerDisplay.text = formatTime(ms)
    }

    private fun onTimerFinished() {
        binding.textTimerDisplay.text = "00:00"
        binding.textTimerFinished.visibility = View.VISIBLE
        binding.root.postDelayed({
            binding.textTimerFinished.visibility = View.GONE
        }, 3000)
        resetUI()
    }

    private fun resetUI() {
        binding.btnStart.visibility = View.VISIBLE
        binding.btnPause.visibility = View.GONE
        binding.btnResume.visibility = View.GONE
        binding.btnStop.visibility = View.GONE
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = ms / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    override fun onStart() {
        super.onStart()
        requireContext().registerReceiver(tickReceiver, IntentFilter(TimerService.BROADCAST_TICK))
        requireContext().registerReceiver(finishReceiver, IntentFilter(TimerService.BROADCAST_FINISH))
    }

    override fun onStop() {
        super.onStop()
        requireContext().unregisterReceiver(tickReceiver)
        requireContext().unregisterReceiver(finishReceiver)
        if (isBound) {
            requireContext().unbindService(serviceConnection)
            isBound = false
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
