package com.offlinepal.notes

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.offlinepal.databinding.FragmentNotesBinding

class NotesFragment : Fragment() {

    private var _binding: FragmentNotesBinding? = null
    private val binding get() = _binding!!
    private val viewModel: NoteViewModel by viewModels()
    private lateinit var adapter: NoteAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNotesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupSearch()
        observeNotes()

        binding.fabNewNote.setOnClickListener {
            startActivity(Intent(requireContext(), NoteEditorActivity::class.java))
        }
    }

    private fun setupRecyclerView() {
        adapter = NoteAdapter(
            onNoteClick = { note ->
                val intent = Intent(requireContext(), NoteEditorActivity::class.java)
                intent.putExtra(NoteEditorActivity.EXTRA_NOTE_ID, note.id)
                startActivity(intent)
            },
            onNoteLongClick = { note ->
                showDeleteConfirmation(note)
            }
        )
        binding.recyclerNotes.apply {
            layoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
            adapter = this@NotesFragment.adapter
        }
    }

    private fun setupSearch() {
        binding.searchViewNotes.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = false
            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.setSearchQuery(newText ?: "")
                return true
            }
        })
    }

    private fun observeNotes() {
        viewModel.notes.observe(viewLifecycleOwner) { notes ->
            adapter.submitList(notes)
            binding.emptyState.visibility = if (notes.isEmpty()) View.VISIBLE else View.GONE
            binding.recyclerNotes.visibility = if (notes.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun showDeleteConfirmation(note: Note) {
        Snackbar.make(binding.root, "Delete \"${note.title}\"?", Snackbar.LENGTH_LONG)
            .setAction("DELETE") {
                viewModel.delete(note)
                Snackbar.make(binding.root, "Note deleted", Snackbar.LENGTH_SHORT)
                    .setAction("UNDO") { viewModel.insert(note) }
                    .show()
            }
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
