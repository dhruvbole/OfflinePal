package com.offlinepal.quiz

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ─── Entity ───────────────────────────────────────────────────────────────────

@Entity(tableName = "quiz_cards")
data class QuizCard(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val question: String,
    val answer: String,
    val category: String = "General",
    val timesShown: Int = 0,
    val timesCorrect: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

// ─── DAO ──────────────────────────────────────────────────────────────────────

@Dao
interface QuizDao {

    @Query("SELECT * FROM quiz_cards ORDER BY createdAt DESC")
    fun getAllCards(): Flow<List<QuizCard>>

    @Query("SELECT * FROM quiz_cards WHERE category = :category ORDER BY RANDOM() LIMIT :limit")
    suspend fun getRandomCards(category: String, limit: Int): List<QuizCard>

    @Query("SELECT * FROM quiz_cards ORDER BY RANDOM() LIMIT :limit")
    suspend fun getRandomCards(limit: Int): List<QuizCard>

    @Query("SELECT DISTINCT category FROM quiz_cards")
    fun getCategories(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(card: QuizCard): Long

    @Update
    suspend fun update(card: QuizCard)

    @Delete
    suspend fun delete(card: QuizCard)

    @Query("SELECT COUNT(*) FROM quiz_cards")
    suspend fun getCount(): Int
}
