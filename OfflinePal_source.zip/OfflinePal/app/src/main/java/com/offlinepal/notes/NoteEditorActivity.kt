package com.offlinepal.notes

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.offlinepal.R
import com.offlinepal.databinding.ActivityNoteEditorBinding
import kotlinx.coroutines.launch

class NoteEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNoteEditorBinding
    private val viewModel: NoteViewModel by viewModels()

    private var noteId: Long = -1L
    private var currentNote: Note? = null
    private var selectedColor: Int = 0
    private var isPinned: Boolean = false

    companion object {
        const val EXTRA_NOTE_ID = "extra_note_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNoteEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbarEditor)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = ""

        noteId = intent.getLongExtra(EXTRA_NOTE_ID, -1L)

        if (noteId != -1L) {
            loadNote()
        }

        setupColorPicker()
    }

    private fun loadNote() {
        lifecycleScope.launch {
            val note = viewModel.getNoteById(noteId)
            note?.let {
                currentNote = it
                binding.editNoteTitle.setText(it.title)
                binding.editNoteContent.setText(it.content)
                selectedColor = it.color
                isPinned = it.isPinned
                updateColorUI()
            }
        }
    }

    private fun setupColorPicker() {
        val colorButtons = listOf(
            binding.colorDefault,
            binding.colorYellow,
            binding.colorGreen,
            binding.colorBlue,
            binding.colorPink
        )

        colorButtons.forEachIndexed { index, button ->
            button.setOnClickListener {
                selectedColor = index
                updateColorUI()
            }
        }
    }

    private fun updateColorUI() {
        val colors = listOf(
            R.color.note_default,
            R.color.note_yellow,
            R.color.note_green,
            R.color.note_blue,
            R.color.note_pink
        )
        val colorRes = colors.getOrElse(selectedColor) { R.color.note_default }
        binding.editorRoot.setBackgroundColor(getColor(colorRes))
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_note_editor, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                saveAndExit()
                true
            }
            R.id.action_pin -> {
                isPinned = !isPinned
                item.setIcon(if (isPinned) R.drawable.ic_pin_filled else R.drawable.ic_pin_outline)
                true
            }
            R.id.action_delete -> {
                if (noteId != -1L) {
                    viewModel.delete(currentNote ?: return true)
                }
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        saveAndExit()
    }

    private fun saveAndExit() {
        val title = binding.editNoteTitle.text.toString().trim()
        val content = binding.editNoteContent.text.toString().trim()

        if (title.isBlank() && content.isBlank()) {
            finish()
            return
        }

        if (noteId == -1L) {
            viewModel.insert(
                Note(
                    title = title.ifBlank { "Untitled" },
                    content = content,
                    color = selectedColor,
                    isPinned = isPinned
                )
            )
        } else {
            currentNote?.let {
                viewModel.update(
                    it.copy(
                        title = title.ifBlank { "Untitled" },
                        content = content,
                        color = selectedColor,
                        isPinned = isPinned
                    )
                )
            }
        }

        Toast.makeText(this, "Note saved", Toast.LENGTH_SHORT).show()
        finish()
    }
}
