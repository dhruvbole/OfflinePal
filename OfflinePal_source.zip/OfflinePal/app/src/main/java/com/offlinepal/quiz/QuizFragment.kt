package com.offlinepal.quiz

import android.animation.AnimatorInflater
import android.animation.AnimatorSet
import android.os.Bundle
import android.view.*
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.offlinepal.R
import com.offlinepal.databinding.FragmentQuizBinding

class QuizFragment : Fragment() {

    private var _binding: FragmentQuizBinding? = null
    private val binding get() = _binding!!
    private val viewModel: QuizViewModel by viewModels()

    private lateinit var frontAnim: AnimatorSet
    private lateinit var backAnim: AnimatorSet
    private var isFront = true

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuizBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupFlipAnimation()
        observeViewModel()
        viewModel.seedDefaultCards()

        binding.btnStartSession.setOnClickListener {
            viewModel.startSession(count = 10)
        }

        binding.cardFlashcard.setOnClickListener {
            viewModel.flipCard()
        }

        binding.btnCorrect.setOnClickListener { viewModel.markCorrect() }
        binding.btnWrong.setOnClickListener { viewModel.markWrong() }

        binding.btnAddCard.setOnClickListener { showAddCardDialog() }

        binding.btnManageCards.setOnClickListener {
            binding.viewFlipper.displayedChild = 2  // card list view
        }

        binding.btnBackToQuiz.setOnClickListener {
            binding.viewFlipper.displayedChild = 0  // main quiz view
        }
    }

    private fun setupFlipAnimation() {
        val scale = requireContext().resources.displayMetrics.density
        binding.cardFront.cameraDistance = 8000 * scale
        binding.cardBack.cameraDistance = 8000 * scale

        frontAnim = AnimatorInflater.loadAnimator(
            requireContext(), R.animator.card_flip_left_out
        ) as AnimatorSet
        backAnim = AnimatorInflater.loadAnimator(
            requireContext(), R.animator.card_flip_right_in
        ) as AnimatorSet
    }

    private fun flipCard() {
        if (isFront) {
            frontAnim.setTarget(binding.cardFront)
            backAnim.setTarget(binding.cardBack)
            frontAnim.start()
            backAnim.start()
            binding.cardFront.visibility = View.GONE
            binding.cardBack.visibility = View.VISIBLE
        } else {
            val flipOutAnim = AnimatorInflater.loadAnimator(
                requireContext(), R.animator.card_flip_right_out
            ) as AnimatorSet
            val flipInAnim = AnimatorInflater.loadAnimator(
                requireContext(), R.animator.card_flip_left_in
            ) as AnimatorSet
            flipOutAnim.setTarget(binding.cardBack)
            flipInAnim.setTarget(binding.cardFront)
            flipOutAnim.start()
            flipInAnim.start()
            binding.cardBack.visibility = View.GONE
            binding.cardFront.visibility = View.VISIBLE
        }
        isFront = !isFront
    }

    private fun observeViewModel() {
        viewModel.sessionCards.observe(viewLifecycleOwner) { cards ->
            if (cards.isNotEmpty()) {
                binding.viewFlipper.displayedChild = 1 // quiz session view
            }
        }

        viewModel.currentIndex.observe(viewLifecycleOwner) { index ->
            val cards = viewModel.sessionCards.value ?: return@observe
            if (index < cards.size) {
                val card = cards[index]
                binding.textQuestion.text = card.question
                binding.textAnswer.text = card.answer
                binding.textCategory.text = card.category
                binding.textProgress.text = "${index + 1} / ${cards.size}"
                binding.progressQuiz.progress = ((index.toFloat() / cards.size) * 100).toInt()

                // Reset card to front
                isFront = true
                binding.cardFront.visibility = View.VISIBLE
                binding.cardBack.visibility = View.GONE
            }
        }

        viewModel.isFlipped.observe(viewLifecycleOwner) { flipped ->
            val currentlyFront = !flipped
            if (currentlyFront != isFront) {
                flipCard()
            }
            binding.btnCorrect.isEnabled = flipped
            binding.btnWrong.isEnabled = flipped
        }

        viewModel.sessionFinished.observe(viewLifecycleOwner) { finished ->
            if (finished) {
                val score = viewModel.score.value ?: 0
                val total = viewModel.sessionCards.value?.size ?: 0
                binding.viewFlipper.displayedChild = 0
                showResultDialog(score, total)
            }
        }

        viewModel.allCards.observe(viewLifecycleOwner) { cards ->
            binding.textCardCount.text = "${cards.size} cards in library"
        }
    }

    private fun showResultDialog(score: Int, total: Int) {
        val percent = if (total > 0) (score * 100) / total else 0
        val emoji = when {
            percent >= 90 -> "🏆"
            percent >= 70 -> "⭐"
            percent >= 50 -> "👍"
            else -> "📚"
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("$emoji Session Complete!")
            .setMessage("You got $score out of $total correct ($percent%).\n\nKeep practicing to improve!")
            .setPositiveButton("Play Again") { _, _ -> viewModel.startSession() }
            .setNegativeButton("Done", null)
            .show()
    }

    private fun showAddCardDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_card, null)
        val editQuestion = dialogView.findViewById<EditText>(R.id.editQuestion)
        val editAnswer = dialogView.findViewById<EditText>(R.id.editAnswer)
        val editCategory = dialogView.findViewById<EditText>(R.id.editCardCategory)

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Add Flashcard")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val q = editQuestion.text.toString().trim()
                val a = editAnswer.text.toString().trim()
                val cat = editCategory.text.toString().trim().ifBlank { "General" }
                if (q.isNotBlank() && a.isNotBlank()) {
                    viewModel.insert(QuizCard(question = q, answer = a, category = cat))
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
