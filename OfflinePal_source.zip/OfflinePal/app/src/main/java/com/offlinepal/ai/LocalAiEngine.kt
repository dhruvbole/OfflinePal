package com.offlinepal.ai

import android.content.Context
import android.util.Log
import org.tensorflow.lite.task.text.qa.BertQuestionAnswerer
import org.tensorflow.lite.task.text.qa.QaAnswer

/**
 * LocalAiEngine — fully offline AI assistant.
 *
 * Strategy (layered):
 * 1. MobileBERT on-device Q&A (uses bundled .tflite model)
 * 2. Rule-based knowledge base for common questions
 * 3. Text processing utilities (summarize, count words, etc.)
 * 4. Graceful fallback with helpful suggestions
 */
class LocalAiEngine(private val context: Context) {

    private var bertAnswerer: BertQuestionAnswerer? = null
    private var isModelLoaded = false

    init {
        loadModel()
    }

    private fun loadModel() {
        try {
            // MobileBERT model — bundled in assets/model/mobilebert.tflite
            bertAnswerer = BertQuestionAnswerer.createFromFile(
                context, "model/mobilebert.tflite"
            )
            isModelLoaded = true
            Log.i(TAG, "MobileBERT model loaded successfully")
        } catch (e: Exception) {
            Log.w(TAG, "TFLite model not found or failed to load, using rule-based fallback: ${e.message}")
            isModelLoaded = false
        }
    }

    data class AiResponse(
        val text: String,
        val confidence: Float = 1.0f,
        val source: String = "knowledge"
    )

    /**
     * Main entry point. Processes user input and returns a response.
     */
    fun process(userInput: String): AiResponse {
        val input = userInput.trim()
        if (input.isBlank()) return AiResponse("Please type a question or message.")

        // 1. Check for utility commands
        val utilityResponse = handleUtilityCommand(input)
        if (utilityResponse != null) return utilityResponse

        // 2. Check rule-based knowledge base
        val ruleResponse = knowledgeBase.findAnswer(input)
        if (ruleResponse != null) return AiResponse(ruleResponse, source = "knowledge-base")

        // 3. Try MobileBERT contextual Q&A if model is loaded
        if (isModelLoaded && bertAnswerer != null) {
            val bertResponse = tryBertAnswer(input)
            if (bertResponse != null) return bertResponse
        }

        // 4. Attempt to provide a helpful response based on question type
        return handleGeneralInput(input)
    }

    private fun handleUtilityCommand(input: String): AiResponse? {
        val lower = input.lowercase().trim()

        // Word counter
        if (lower.startsWith("count words") || lower.startsWith("word count")) {
            val text = input.removePrefix("count words").removePrefix("word count").trim()
            if (text.isNotBlank()) {
                val count = text.split("\\s+".toRegex()).filter { it.isNotBlank() }.size
                return AiResponse("📝 \"$text\" has **$count** word${if (count != 1) "s" else ""}.")
            }
        }

        // Character counter
        if (lower.startsWith("count chars") || lower.startsWith("char count")) {
            val text = input.removePrefix("count chars").removePrefix("char count").trim()
            return AiResponse("🔤 That text has **${text.length}** characters.")
        }

        // Summarize command
        if (lower.startsWith("summarize:") || lower.startsWith("summarize ")) {
            val text = input.substringAfter(":").trim().ifBlank {
                input.removePrefix("summarize").trim()
            }
            return AiResponse(summarizeText(text), source = "summarizer")
        }

        // Math calculations
        if (lower.matches(Regex("^[\\d+\\-*/().\\s%^]+$")) || lower.startsWith("calculate") || lower.startsWith("compute")) {
            val expr = lower.replace("calculate", "").replace("compute", "").trim()
            val mathResult = tryCalculate(expr)
            if (mathResult != null) return AiResponse("🔢 $expr = **$mathResult**", source = "calculator")
        }

        // Unit conversions
        val conversionResult = tryUnitConversion(lower)
        if (conversionResult != null) return AiResponse(conversionResult, source = "converter")

        // Help
        if (lower == "help" || lower == "?" || lower == "what can you do") {
            return AiResponse(HELP_TEXT, source = "help")
        }

        return null
    }

    private fun tryBertAnswer(question: String): AiResponse? {
        return try {
            // MobileBERT needs a passage context. Use the knowledge base passages.
            val context = knowledgeBase.getBestPassage(question)
            if (context.isNullOrBlank()) return null

            val answers: List<QaAnswer> = bertAnswerer!!.answer(context, question)
            if (answers.isNotEmpty() && answers[0].text.isNotBlank()) {
                val best = answers[0]
                if (best.pos.logit > -5f) { // confidence threshold
                    return AiResponse(
                        "🤖 ${best.text.trim().replaceFirstChar { it.uppercase() }}",
                        confidence = best.pos.logit,
                        source = "MobileBERT"
                    )
                }
            }
            null
        } catch (e: Exception) {
            Log.e(TAG, "BERT inference error: ${e.message}")
            null
        }
    }

    private fun handleGeneralInput(input: String): AiResponse {
        val lower = input.lowercase()

        // Greetings
        if (lower.matches(Regex("(hi|hello|hey|howdy|greetings|good morning|good evening|good afternoon).*"))) {
            val greetings = listOf("Hello! 👋 How can I help you today?",
                "Hi there! I'm your offline assistant. Ask me anything!",
                "Hey! Ready to help. What do you need?")
            return AiResponse(greetings.random())
        }

        // Thanks
        if (lower.contains("thank")) {
            return AiResponse("You're welcome! 😊 Let me know if you need anything else.")
        }

        // Yes/No questions about capabilities
        if (lower.contains("can you") || lower.contains("are you able")) {
            return AiResponse(
                "I'm an offline AI assistant. I can answer general knowledge questions, " +
                "do math calculations, convert units, count words, and summarize text. " +
                "Type **help** to see all commands."
            )
        }

        // Default intelligent fallback
        val wordCount = input.split("\\s+".toRegex()).size
        return if (wordCount > 20) {
            AiResponse(summarizeText(input), source = "summarizer")
        } else {
            AiResponse(
                "I'm not sure about that specific question. Here are some things I can help with:\n\n" +
                "• Ask a **general knowledge** question\n" +
                "• Type **calculate** followed by a math expression\n" +
                "• Type **summarize:** followed by text to summarize\n" +
                "• Ask for **unit conversions** (e.g., '5 km to miles')\n" +
                "• Type **help** for all commands"
            )
        }
    }

    private fun summarizeText(text: String): String {
        if (text.length < 100) return "📄 Text is already short: \"$text\""

        val sentences = text.split(Regex("[.!?]+")).filter { it.trim().length > 10 }
        if (sentences.isEmpty()) return "Could not parse text into sentences."

        // Simple extractive summarization: pick first sentence + most informative
        val summary = if (sentences.size <= 3) {
            sentences.joinToString(". ")
        } else {
            // Score sentences by word importance
            val wordFreq = text.lowercase()
                .split("\\s+".toRegex())
                .filter { it.length > 4 }
                .groupingBy { it }
                .eachCount()

            val scored = sentences.mapIndexed { idx, sent ->
                val score = sent.lowercase().split("\\s+".toRegex())
                    .sumOf { wordFreq[it] ?: 0 }
                Pair(idx, score)
            }.sortedByDescending { it.second }

            val topIndices = scored.take(3).map { it.first }.sorted()
            topIndices.map { sentences[it].trim() }.joinToString(". ") + "."
        }

        val reduction = ((1 - summary.length.toFloat() / text.length) * 100).toInt()
        return "📋 **Summary** (${reduction}% shorter):\n\n$summary"
    }

    private fun tryCalculate(expr: String): String? {
        return try {
            val clean = expr.replace(" ", "").replace("%", "/100.0*")
            val result = evaluate(clean)
            if (result == result.toLong().toDouble()) result.toLong().toString()
            else String.format("%.4f", result).trimEnd('0').trimEnd('.')
        } catch (e: Exception) {
            null
        }
    }

    // Simple recursive descent math expression evaluator
    private fun evaluate(expr: String): Double {
        var pos = 0

        fun parseNumber(): Double {
            val start = pos
            if (pos < expr.length && (expr[pos] == '-' || expr[pos] == '+')) pos++
            while (pos < expr.length && (expr[pos].isDigit() || expr[pos] == '.')) pos++
            return expr.substring(start, pos).toDouble()
        }

        fun parseFactor(): Double {
            if (pos < expr.length && expr[pos] == '(') {
                pos++ // skip '('
                val result = parseExpr()
                if (pos < expr.length && expr[pos] == ')') pos++
                return result
            }
            return parseNumber()
        }

        fun parseTerm(): Double {
            var result = parseFactor()
            while (pos < expr.length && (expr[pos] == '*' || expr[pos] == '/')) {
                val op = expr[pos++]
                val right = parseFactor()
                result = if (op == '*') result * right else result / right
            }
            return result
        }

        fun parseExpr(): Double {
            var result = parseTerm()
            while (pos < expr.length && (expr[pos] == '+' || expr[pos] == '-')) {
                val op = expr[pos++]
                result = if (op == '+') result + parseTerm() else result - parseTerm()
            }
            return result
        }

        fun parseExprOuter(): Double = parseExpr()
        return parseExprOuter()
    }

    private fun tryUnitConversion(input: String): String? {
        val patterns = listOf(
            Regex("(\\d+\\.?\\d*)\\s*km\\s*to\\s*miles?") to { v: Double -> "${v * 0.621371} miles" },
            Regex("(\\d+\\.?\\d*)\\s*miles?\\s*to\\s*km") to { v: Double -> "${v * 1.60934} km" },
            Regex("(\\d+\\.?\\d*)\\s*kg\\s*to\\s*(lbs?|pounds?)") to { v: Double -> "${v * 2.20462} lbs" },
            Regex("(\\d+\\.?\\d*)\\s*(lbs?|pounds?)\\s*to\\s*kg") to { v: Double -> "${v * 0.453592} kg" },
            Regex("(\\d+\\.?\\d*)\\s*celsius\\s*to\\s*fahrenheit") to { v: Double -> "${v * 9 / 5 + 32}°F" },
            Regex("(\\d+\\.?\\d*)\\s*fahrenheit\\s*to\\s*celsius") to { v: Double -> "${(v - 32) * 5 / 9}°C" },
            Regex("(\\d+\\.?\\d*)\\s*m\\s*to\\s*(ft|feet)") to { v: Double -> "${v * 3.28084} feet" },
            Regex("(\\d+\\.?\\d*)\\s*(ft|feet)\\s*to\\s*m") to { v: Double -> "${v * 0.3048} m" },
            Regex("(\\d+\\.?\\d*)\\s*liters?\\s*to\\s*(gallons?|gal)") to { v: Double -> "${v * 0.264172} gallons" },
            Regex("(\\d+\\.?\\d*)\\s*(gallons?|gal)\\s*to\\s*liters?") to { v: Double -> "${v * 3.78541} liters" }
        )

        for ((pattern, converter) in patterns) {
            val match = pattern.find(input)
            if (match != null) {
                val value = match.groupValues[1].toDoubleOrNull() ?: continue
                val result = converter(value)
                return "🔄 $value ${match.value.substringBefore(" to").trim()} = **$result**"
            }
        }
        return null
    }

    private val HELP_TEXT = """
🤖 **OfflinePal AI Assistant** — fully offline

**General Q&A:**
• Ask any factual question
• "What is the speed of light?"
• "Who invented the telephone?"

**Calculations:**
• "calculate 15% of 250"
• "compute 123 * 456"

**Unit Conversions:**
• "10 km to miles"
• "72 fahrenheit to celsius"
• "5 kg to lbs"

**Text Tools:**
• "summarize: [your text here]"
• "count words [your text]"
• "count chars [your text]"

All processing happens on your device — no internet needed!
    """.trimIndent()

    fun close() {
        bertAnswerer?.close()
    }

    companion object {
        private const val TAG = "LocalAiEngine"
    }
}
