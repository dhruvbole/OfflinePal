package com.offlinepal.notes

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.offlinepal.R
import com.offlinepal.databinding.ItemNoteBinding
import java.text.SimpleDateFormat
import java.util.*

class NoteAdapter(
    private val onNoteClick: (Note) -> Unit,
    private val onNoteLongClick: (Note) -> Unit
) : ListAdapter<Note, NoteAdapter.NoteViewHolder>(DIFF_CALLBACK) {

    private val dateFormat = SimpleDateFormat("MMM d", Locale.getDefault())

    private val noteColors = intArrayOf(
        R.color.note_default,
        R.color.note_yellow,
        R.color.note_green,
        R.color.note_blue,
        R.color.note_pink
    )

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val binding = ItemNoteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NoteViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class NoteViewHolder(private val binding: ItemNoteBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(note: Note) {
            binding.textNoteTitle.text = note.title.ifBlank { "Untitled" }
            binding.textNoteContent.text = note.content
            binding.textNoteDate.text = dateFormat.format(Date(note.updatedAt))

            val colorRes = if (note.color in 0..4) noteColors[note.color] else noteColors[0]
            binding.cardNote.setCardBackgroundColor(
                binding.root.context.getColor(colorRes)
            )

            if (note.isPinned) {
                binding.iconPin.visibility = android.view.View.VISIBLE
            } else {
                binding.iconPin.visibility = android.view.View.GONE
            }

            binding.root.setOnClickListener { onNoteClick(note) }
            binding.root.setOnLongClickListener {
                onNoteLongClick(note)
                true
            }
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Note>() {
            override fun areItemsTheSame(oldItem: Note, newItem: Note) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Note, newItem: Note) = oldItem == newItem
        }
    }
}
