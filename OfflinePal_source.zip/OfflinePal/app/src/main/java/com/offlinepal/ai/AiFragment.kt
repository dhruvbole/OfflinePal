package com.offlinepal.ai

import android.os.Bundle
import android.view.*
import android.view.inputmethod.EditorInfo
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.offlinepal.databinding.FragmentAiBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AiFragment : Fragment() {

    private var _binding: FragmentAiBinding? = null
    private val binding get() = _binding!!

    private lateinit var chatAdapter: ChatAdapter
    private lateinit var aiEngine: LocalAiEngine
    private val messages = mutableListOf<ChatMessage>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAiBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        aiEngine = LocalAiEngine(requireContext())

        setupRecyclerView()
        setupInput()

        // Welcome message
        addAssistantMessage(
            "👋 Hello! I'm your **offline AI assistant**.\n\n" +
            "I can answer questions, do math, convert units, and summarize text — " +
            "all without any internet connection.\n\n" +
            "Type **help** to see everything I can do!"
        )

        // Quick action chips
        binding.chipHelp.setOnClickListener { sendMessage("help") }
        binding.chipCalculate.setOnClickListener { sendMessage("calculate 15% of 250") }
        binding.chipConvert.setOnClickListener { sendMessage("10 km to miles") }
        binding.chipSummarize.setOnClickListener {
            binding.editInput.setText("summarize: ")
            binding.editInput.requestFocus()
            binding.editInput.setSelection(binding.editInput.text.length)
        }
    }

    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter(messages)
        binding.recyclerChat.apply {
            layoutManager = LinearLayoutManager(requireContext()).apply {
                stackFromEnd = true
            }
            adapter = chatAdapter
        }
    }

    private fun setupInput() {
        binding.btnSend.setOnClickListener {
            val text = binding.editInput.text.toString().trim()
            if (text.isNotBlank()) sendMessage(text)
        }

        binding.editInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                val text = binding.editInput.text.toString().trim()
                if (text.isNotBlank()) sendMessage(text)
                true
            } else false
        }
    }

    private fun sendMessage(text: String) {
        binding.editInput.setText("")

        // Add user message
        addUserMessage(text)

        // Show typing indicator
        val typingMsg = ChatMessage("...", isUser = false, isTyping = true)
        messages.add(typingMsg)
        chatAdapter.notifyItemInserted(messages.size - 1)
        scrollToBottom()

        // Process in background
        lifecycleScope.launch(Dispatchers.IO) {
            val response = aiEngine.process(text)

            withContext(Dispatchers.Main) {
                // Remove typing indicator
                val typingIdx = messages.indexOf(typingMsg)
                if (typingIdx >= 0) {
                    messages.removeAt(typingIdx)
                    chatAdapter.notifyItemRemoved(typingIdx)
                }
                addAssistantMessage(response.text)
            }
        }
    }

    private fun addUserMessage(text: String) {
        messages.add(ChatMessage(text, isUser = true))
        chatAdapter.notifyItemInserted(messages.size - 1)
        scrollToBottom()
    }

    private fun addAssistantMessage(text: String) {
        messages.add(ChatMessage(text, isUser = false))
        chatAdapter.notifyItemInserted(messages.size - 1)
        scrollToBottom()
    }

    private fun scrollToBottom() {
        binding.recyclerChat.post {
            if (messages.isNotEmpty()) {
                binding.recyclerChat.smoothScrollToPosition(messages.size - 1)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        aiEngine.close()
        _binding = null
    }
}

// ─── Data Model ───────────────────────────────────────────────────────────────

data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val isTyping: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
