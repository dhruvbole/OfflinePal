package com.offlinepal.ai

import android.text.Html
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.offlinepal.databinding.ItemChatUserBinding
import com.offlinepal.databinding.ItemChatAssistantBinding
import java.text.SimpleDateFormat
import java.util.*

class ChatAdapter(private val messages: List<ChatMessage>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val VIEW_TYPE_USER = 0
        const val VIEW_TYPE_ASSISTANT = 1
    }

    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun getItemViewType(position: Int): Int {
        return if (messages[position].isUser) VIEW_TYPE_USER else VIEW_TYPE_ASSISTANT
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_USER) {
            val binding = ItemChatUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            UserViewHolder(binding)
        } else {
            val binding = ItemChatAssistantBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            AssistantViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val msg = messages[position]
        when (holder) {
            is UserViewHolder -> holder.bind(msg)
            is AssistantViewHolder -> holder.bind(msg)
        }
    }

    override fun getItemCount() = messages.size

    inner class UserViewHolder(private val binding: ItemChatUserBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(msg: ChatMessage) {
            binding.textUserMessage.text = msg.text
            binding.textUserTime.text = timeFormat.format(Date(msg.timestamp))
        }
    }

    inner class AssistantViewHolder(private val binding: ItemChatAssistantBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(msg: ChatMessage) {
            if (msg.isTyping) {
                binding.textAssistantMessage.text = "Thinking..."
                binding.progressTyping.visibility = View.VISIBLE
            } else {
                // Convert simple markdown: **bold**, bullet points
                val html = msg.text
                    .replace("**", "<b>").let { text ->
                        // Close every other <b> as </b>
                        var count = 0
                        text.replace("<b>") { if (count++ % 2 == 0) "<b>" else "</b>" }
                    }
                    .replace("\n", "<br/>")
                    .replace("•", "&#8226;")
                binding.textAssistantMessage.text = Html.fromHtml(html, Html.FROM_HTML_MODE_COMPACT)
                binding.progressTyping.visibility = View.GONE
            }
            binding.textAssistantTime.text = timeFormat.format(Date(msg.timestamp))
        }
    }
}
