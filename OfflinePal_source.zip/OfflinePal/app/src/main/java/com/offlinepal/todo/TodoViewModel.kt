package com.offlinepal.todo

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.offlinepal.AppDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch

class TodoViewModel(application: Application) : AndroidViewModel(application) {

    private val dao: TodoDao = AppDatabase.getDatabase(application).todoDao()

    // 0 = all, 1 = active, 2 = completed
    private val filterMode = MutableStateFlow(0)

    val todos: LiveData<List<TodoItem>> = filterMode.flatMapLatest { mode ->
        when (mode) {
            1 -> dao.getActiveTodos()
            2 -> dao.getCompletedTodos()
            else -> dao.getAllTodos()
        }
    }.asLiveData()

    val activeCount: LiveData<Int> = dao.getActiveCount().asLiveData()

    fun setFilter(mode: Int) {
        filterMode.value = mode
    }

    fun insert(item: TodoItem) = viewModelScope.launch {
        dao.insert(item)
    }

    fun toggleComplete(item: TodoItem) = viewModelScope.launch {
        dao.update(item.copy(isCompleted = !item.isCompleted))
    }

    fun delete(item: TodoItem) = viewModelScope.launch {
        dao.delete(item)
    }

    fun deleteAllCompleted() = viewModelScope.launch {
        dao.deleteAllCompleted()
    }

    fun updatePriority(item: TodoItem, priority: Int) = viewModelScope.launch {
        dao.update(item.copy(priority = priority))
    }
}
