package com.offlinepal.timer

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.*
import androidx.core.app.NotificationCompat
import com.offlinepal.R
import com.offlinepal.ui.MainActivity

class TimerService : Service() {

    companion object {
        const val CHANNEL_ID = "timer_channel"
        const val NOTIF_ID = 1001
        const val ACTION_START = "ACTION_START"
        const val ACTION_PAUSE = "ACTION_PAUSE"
        const val ACTION_STOP = "ACTION_STOP"
        const val EXTRA_DURATION_MS = "extra_duration_ms"
        const val BROADCAST_TICK = "com.offlinepal.TIMER_TICK"
        const val BROADCAST_FINISH = "com.offlinepal.TIMER_FINISH"
        const val EXTRA_REMAINING_MS = "extra_remaining_ms"
        const val EXTRA_IS_RUNNING = "extra_is_running"
    }

    private val binder = TimerBinder()
    private var countdownTimer: CountDownTimer? = null
    private var remainingMs: Long = 0L
    private var isRunning = false
    private var isStopwatch = false
    private var stopwatchMs = 0L
    private val handler = Handler(Looper.getMainLooper())
    private var stopwatchRunnable: Runnable? = null

    inner class TimerBinder : Binder() {
        fun getService(): TimerService = this@TimerService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val durationMs = intent.getLongExtra(EXTRA_DURATION_MS, 0L)
                if (durationMs > 0) {
                    startCountdown(durationMs)
                } else {
                    startStopwatch()
                }
            }
            ACTION_PAUSE -> pauseTimer()
            ACTION_STOP -> stopTimer()
        }
        return START_NOT_STICKY
    }

    fun startCountdown(durationMs: Long) {
        isStopwatch = false
        remainingMs = durationMs
        isRunning = true
        countdownTimer?.cancel()
        countdownTimer = object : CountDownTimer(durationMs, 100) {
            override fun onTick(millisUntilFinished: Long) {
                remainingMs = millisUntilFinished
                broadcastTick(millisUntilFinished, true)
                updateNotification(formatTime(millisUntilFinished), "Countdown")
            }
            override fun onFinish() {
                isRunning = false
                remainingMs = 0
                broadcastFinish()
                vibrate()
                stopForeground(STOP_FOREGROUND_REMOVE)
            }
        }.start()
        startForeground(NOTIF_ID, buildNotification(formatTime(durationMs), "Countdown running"))
    }

    fun startStopwatch() {
        isStopwatch = true
        isRunning = true
        stopwatchMs = 0L
        stopwatchRunnable = object : Runnable {
            override fun run() {
                stopwatchMs += 100
                broadcastTick(stopwatchMs, true)
                updateNotification(formatTime(stopwatchMs), "Stopwatch")
                if (isRunning) handler.postDelayed(this, 100)
            }
        }
        handler.post(stopwatchRunnable!!)
        startForeground(NOTIF_ID, buildNotification("00:00", "Stopwatch running"))
    }

    fun pauseTimer() {
        isRunning = false
        countdownTimer?.cancel()
        stopwatchRunnable?.let { handler.removeCallbacks(it) }
        broadcastTick(if (isStopwatch) stopwatchMs else remainingMs, false)
    }

    fun stopTimer() {
        isRunning = false
        countdownTimer?.cancel()
        stopwatchRunnable?.let { handler.removeCallbacks(it) }
        remainingMs = 0
        stopwatchMs = 0
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    fun resumeTimer() {
        if (isStopwatch) {
            isRunning = true
            handler.post(stopwatchRunnable!!)
        } else if (remainingMs > 0) {
            startCountdown(remainingMs)
        }
    }

    private fun broadcastTick(ms: Long, running: Boolean) {
        val intent = Intent(BROADCAST_TICK).apply {
            putExtra(EXTRA_REMAINING_MS, ms)
            putExtra(EXTRA_IS_RUNNING, running)
        }
        sendBroadcast(intent)
    }

    private fun broadcastFinish() {
        sendBroadcast(Intent(BROADCAST_FINISH))
    }

    private fun vibrate() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500), -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(longArrayOf(0, 500, 200, 500), -1)
        }
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = ms / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Timer", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "OfflinePal timer notifications" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(timeText: String, subtitle: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("OfflinePal Timer")
            .setContentText("$subtitle • $timeText")
            .setSmallIcon(R.drawable.ic_timer)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(timeText: String, subtitle: String) {
        val notif = buildNotification(timeText, subtitle)
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notif)
    }

    override fun onDestroy() {
        countdownTimer?.cancel()
        stopwatchRunnable?.let { handler.removeCallbacks(it) }
        super.onDestroy()
    }
}
