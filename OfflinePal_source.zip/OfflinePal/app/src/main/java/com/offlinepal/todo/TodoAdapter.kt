package com.offlinepal.todo

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.offlinepal.R
import com.offlinepal.databinding.ItemTodoBinding

class TodoAdapter(
    private val onToggle: (TodoItem) -> Unit,
    private val onDelete: (TodoItem) -> Unit,
    private val onPriorityChange: (TodoItem, Int) -> Unit
) : ListAdapter<TodoItem, TodoAdapter.TodoViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TodoViewHolder {
        val binding = ItemTodoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TodoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TodoViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class TodoViewHolder(private val binding: ItemTodoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: TodoItem) {
            binding.checkboxTodo.isChecked = item.isCompleted
            binding.textTodoTitle.text = item.title

            // Strikethrough on completion
            if (item.isCompleted) {
                binding.textTodoTitle.paintFlags =
                    binding.textTodoTitle.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                binding.textTodoTitle.alpha = 0.5f
            } else {
                binding.textTodoTitle.paintFlags =
                    binding.textTodoTitle.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                binding.textTodoTitle.alpha = 1.0f
            }

            // Priority indicator
            val priorityColor = when (item.priority) {
                0 -> R.color.priority_low
                2 -> R.color.priority_high
                else -> R.color.priority_medium
            }
            binding.priorityBar.setBackgroundResource(priorityColor)

            val priorityLabel = when (item.priority) {
                0 -> "Low"
                2 -> "High"
                else -> "Med"
            }
            binding.textPriority.text = priorityLabel

            binding.checkboxTodo.setOnClickListener { onToggle(item) }
            binding.btnDeleteTodo.setOnClickListener { onDelete(item) }
        }
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<TodoItem>() {
            override fun areItemsTheSame(o: TodoItem, n: TodoItem) = o.id == n.id
            override fun areContentsTheSame(o: TodoItem, n: TodoItem) = o == n
        }
    }
}
