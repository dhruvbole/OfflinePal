package com.offlinepal.todo

import android.os.Bundle
import android.view.*
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.offlinepal.R
import com.offlinepal.databinding.FragmentTodoBinding

class TodoFragment : Fragment() {

    private var _binding: FragmentTodoBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TodoViewModel by viewModels()
    private lateinit var adapter: TodoAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTodoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupChipFilters()
        observeData()

        binding.fabAddTodo.setOnClickListener { showAddDialog() }

        binding.btnClearCompleted.setOnClickListener {
            viewModel.deleteAllCompleted()
            Snackbar.make(binding.root, "Completed tasks cleared", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun setupRecyclerView() {
        adapter = TodoAdapter(
            onToggle = { item -> viewModel.toggleComplete(item) },
            onDelete = { item ->
                viewModel.delete(item)
                Snackbar.make(binding.root, "Task deleted", Snackbar.LENGTH_SHORT)
                    .setAction("UNDO") { viewModel.insert(item) }
                    .show()
            },
            onPriorityChange = { item, priority -> viewModel.updatePriority(item, priority) }
        )
        binding.recyclerTodos.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@TodoFragment.adapter
        }
    }

    private fun setupChipFilters() {
        binding.chipAll.setOnClickListener { viewModel.setFilter(0) }
        binding.chipActive.setOnClickListener { viewModel.setFilter(1) }
        binding.chipDone.setOnClickListener { viewModel.setFilter(2) }
    }

    private fun observeData() {
        viewModel.todos.observe(viewLifecycleOwner) { todos ->
            adapter.submitList(todos)
            binding.emptyStateTodo.visibility = if (todos.isEmpty()) View.VISIBLE else View.GONE
            binding.recyclerTodos.visibility = if (todos.isEmpty()) View.GONE else View.VISIBLE
        }

        viewModel.activeCount.observe(viewLifecycleOwner) { count ->
            binding.textTaskCount.text = "$count task${if (count != 1) "s" else ""} remaining"
        }
    }

    private fun showAddDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_todo, null)
        val editText = dialogView.findViewById<EditText>(R.id.editTodoTitle)

        var selectedPriority = 1 // medium default
        val chipLow = dialogView.findViewById<Chip>(R.id.chipLow)
        val chipMed = dialogView.findViewById<Chip>(R.id.chipMedium)
        val chipHigh = dialogView.findViewById<Chip>(R.id.chipHigh)

        chipLow.setOnClickListener { selectedPriority = 0; chipMed.isChecked = false; chipHigh.isChecked = false }
        chipMed.setOnClickListener { selectedPriority = 1; chipLow.isChecked = false; chipHigh.isChecked = false }
        chipHigh.setOnClickListener { selectedPriority = 2; chipLow.isChecked = false; chipMed.isChecked = false }

        MaterialAlertDialogBuilder(requireContext())
            .setTitle("New Task")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val title = editText.text.toString().trim()
                if (title.isNotBlank()) {
                    viewModel.insert(TodoItem(title = title, priority = selectedPriority))
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
