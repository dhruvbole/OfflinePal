# OfflinePal — Complete Build & Installation Guide

> **100% offline Android app** — Notes · Tasks · Timer · Quiz · AI Assistant  
> Target: Android 7.0+ (API 24) · Language: Kotlin · AI: MobileBERT on-device

---

## Table of Contents

1. [What You're Building](#1-what-youre-building)
2. [Prerequisites](#2-prerequisites)
3. [Step-by-Step Build Instructions](#3-step-by-step-build-instructions)
4. [Download the AI Model](#4-download-the-ai-model)
5. [Build the APK](#5-build-the-apk)
6. [Sideload onto Your Phone](#6-sideload-onto-your-phone)
7. [Running the App Offline](#7-running-the-app-offline)
8. [Troubleshooting](#8-troubleshooting)
9. [Project Structure](#9-project-structure)
10. [Feature Reference](#10-feature-reference)
11. [Permissions Explained](#11-permissions-explained)

---

## 1. What You're Building

**OfflinePal** is a self-contained Android app with five features, all working
without any internet connection:

| Tab | Feature | Storage |
|-----|---------|---------|
| 📝 Notes | Create, edit, delete, search, pin, colour-coded notes | Room (SQLite) |
| ✅ Tasks | To-do list with priorities, filters, undo-delete | Room (SQLite) |
| ⏱ Timer | Countdown timer + stopwatch, presets, foreground service | In-memory |
| 🧠 Quiz | Flashcard quiz with flip animation, score tracking, 15 built-in cards | Room (SQLite) |
| 🤖 AI | Offline AI assistant — Q&A, maths, unit conversion, text summariser | In-memory |

The AI uses **MobileBERT** (~25 MB TFLite model) for neural Q&A plus a
built-in knowledge base with 50+ topics as fallback.

---

## 2. Prerequisites

You only need **one thing**: Android Studio (free, ~1 GB download).

### Install Android Studio

1. Go to: https://developer.android.com/studio
2. Download the version for your OS (Windows / Mac / Linux)
3. Run the installer and follow the wizard — accept all defaults
4. On first launch, Android Studio will auto-download the Android SDK

**Minimum specs for your build machine:**
- 8 GB RAM recommended (4 GB minimum)
- 8 GB free disk space
- Windows 8+, macOS 10.14+, or Ubuntu 18.04+
- Java 17 is bundled with Android Studio — you do NOT need to install Java separately

**You do NOT need:**
- A Google account
- Play Store access
- Any paid licence
- Internet on the target phone

---

## 3. Step-by-Step Build Instructions

### 3.1 — Open the Project

1. Launch **Android Studio**
2. Click **"Open"** (not "New Project")
3. Navigate to the `OfflinePal/` folder you received
4. Click **OK** — Android Studio will index the project (takes 1–3 minutes)

You'll see a progress bar at the bottom: *"Gradle: Syncing…"*  
Wait for it to finish. You may see a prompt: **"Trust and Open Project?"** → click **Trust**.

### 3.2 — Let Gradle Sync

Gradle (the build system) will:
- Download all library dependencies (~200 MB, one-time only)
- Compile the Room database schema
- Index all Kotlin source files

When sync finishes you'll see: **"BUILD SUCCESSFUL"** in the Build output tab.

If you see any red errors, see [Troubleshooting](#8-troubleshooting).

---

## 4. Download the AI Model

The MobileBERT model file is **not included** in the source (it's 25 MB binary).
You need to download it **once** before building.

### Option A — Automatic (recommended)

Open a terminal in the `OfflinePal/` directory and run:

```bash
# macOS / Linux
chmod +x download_model.sh
./download_model.sh

# Windows (PowerShell)
Invoke-WebRequest `
  -Uri "https://storage.googleapis.com/download.tensorflow.org/models/tflite/bert_qa/mobilebert_qa_squad.tflite" `
  -OutFile "app\src\main\assets\model\mobilebert.tflite"
```

### Option B — Manual (browser download)

1. Open this URL:  
   `https://storage.googleapis.com/download.tensorflow.org/models/tflite/bert_qa/mobilebert_qa_squad.tflite`
2. Save the file as **`mobilebert.tflite`**
3. Place it at exactly this path inside the project:  
   `OfflinePal/app/src/main/assets/model/mobilebert.tflite`

### Option C — Skip the model (works without it)

If you cannot download the model, **the app still works fully**.  
The AI assistant automatically falls back to its built-in knowledge base
(50+ topics, maths calculator, unit converter, text summariser).  
Just leave the `assets/model/` folder empty.

---

## 5. Build the APK

### 5a — Build from Android Studio (easiest)

1. In the menu bar: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Wait for the build (~1–2 minutes)
3. A notification pops up: **"APK(s) generated successfully"**
4. Click **"locate"** in that notification — this opens the folder containing the APK

The APK will be at:
```
OfflinePal/app/build/outputs/apk/debug/app-debug.apk
```

### 5b — Build from command line

```bash
# From inside the OfflinePal/ directory:

# macOS / Linux
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```

Output APK location:
```
app/build/outputs/apk/debug/app-debug.apk
```

### Release build (optional — smaller, faster APK)

```bash
./gradlew assembleRelease
# Output: app/build/outputs/apk/release/app-release-unsigned.apk
```

> **Note:** Release builds need to be signed before installation.
> For personal sideloading, the debug APK works perfectly.

---

## 6. Sideload onto Your Phone

Sideloading means installing an APK directly, bypassing the Play Store.

### Step 1 — Enable Unknown Sources on your phone

**Android 7 (Nougat) / Android 8 (Oreo):**
1. Open **Settings → Security**
2. Toggle ON: **"Unknown sources"**
3. Tap OK on the warning

**Android 8+ (Oreo and above):**
1. Settings → Apps (or Application Manager)
2. Tap the three-dot menu → Special app access
3. Tap **"Install unknown apps"**
4. Find **"Files"** (or your file manager) → Enable **"Allow from this source"**

### Step 2 — Transfer the APK to your phone

**Method A — USB cable:**
1. Connect phone to computer via USB
2. On the phone: pull down notifications → tap **"USB charging"** → select **"File Transfer"** (MTP)
3. On your computer, copy `app-debug.apk` to your phone's Downloads folder
4. Disconnect USB

**Method B — SD card:**
1. Copy `app-debug.apk` to a microSD card
2. Insert card into phone

**Method C — Email to yourself:**
1. Email `app-debug.apk` to any email account you can access on the phone
2. Open the email on the phone and download the attachment

**Method D — Local Wi-Fi transfer (no internet needed):**
Use apps like **LocalSend** or **Xender** to transfer over Wi-Fi Direct.

### Step 3 — Install the APK

1. Open your phone's **Files** or **My Files** app
2. Navigate to **Downloads** (or wherever you copied the APK)
3. Tap **app-debug.apk**
4. Tap **"Install"** on the prompt
5. Tap **"Done"** when finished

**OfflinePal** now appears in your app drawer. 🎉

### Step 4 — First launch

1. Open **OfflinePal** from your app drawer
2. The splash screen appears for ~2 seconds
3. You land on the **Notes** tab — all five tabs are accessible via the bottom navigation bar

---

## 7. Running the App Offline

**Everything works without any internet connection.**

| Feature | Works offline? | Notes |
|---------|---------------|-------|
| Notes — create/edit/delete | ✅ Yes | Stored in SQLite on device |
| Notes — search | ✅ Yes | Local full-text search |
| Tasks — add/complete/delete | ✅ Yes | Stored in SQLite on device |
| Timer — countdown | ✅ Yes | Continues when screen is off |
| Timer — stopwatch | ✅ Yes | Shows in notification bar |
| Quiz — flashcards | ✅ Yes | 15 cards pre-loaded; add your own |
| AI — general knowledge | ✅ Yes | 50+ built-in topic answers |
| AI — maths calculator | ✅ Yes | e.g. "calculate 15% of 250" |
| AI — unit conversion | ✅ Yes | e.g. "10 km to miles" |
| AI — text summariser | ✅ Yes | e.g. "summarize: [your text]" |
| AI — MobileBERT neural Q&A | ✅ Yes | Requires model file in assets/ |

**Data persistence:** All notes, tasks, and quiz cards are stored in a local
SQLite database via Room. They survive app restarts, reboots, and updates.

**Battery:** The timer uses a foreground service so it keeps running accurately
even when the phone screen is off. Tap "Stop" when done to end the service.

---

## 8. Troubleshooting

### "Gradle sync failed" / Red errors in Android Studio

**Fix 1 — Refresh Gradle:**
File → Sync Project with Gradle Files

**Fix 2 — Clean and rebuild:**
Build → Clean Project, then Build → Rebuild Project

**Fix 3 — Invalidate caches:**
File → Invalidate Caches → Invalidate and Restart

**Fix 4 — JDK mismatch:**
File → Project Structure → SDK Location → Gradle JDK
Make sure it's set to **"Embedded JDK"** (bundled with Android Studio).

---

### "Minimum SDK version" warning

If you see: *"App requires API 24 but device is API 23"*

Your phone runs Android 6 (Marshmallow). Open `app/build.gradle` and change:
```gradle
minSdk 24
```
to:
```gradle
minSdk 21
```
Then rebuild. All features still work on Android 5+.

---

### "INSTALL_FAILED_UNKNOWN_SOURCES"

You haven't enabled unknown sources. See [Step 1 in section 6](#step-1--enable-unknown-sources-on-your-phone).

---

### "App not installed" error

Possible causes:
- Not enough storage space on the phone (APK is ~15–50 MB with model)
- An older version of the same app is installed — uninstall it first
- The APK transfer was incomplete — retransfer and try again

---

### Timer stops when screen turns off

Some Android phones (especially Xiaomi, Huawei, Samsung with aggressive
battery optimisation) kill background services. Fix:

**Settings → Battery → Battery optimisation → OfflinePal → Don't optimise**

The exact path varies by phone brand.

---

### AI gives "I'm not sure" for every question

The MobileBERT model file is missing from `assets/model/`. Either:
- Run `./download_model.sh` and rebuild, or
- The app still works via the built-in knowledge base — try asking about
  topics like "speed of light", "capital of France", or "calculate 5*12"

---

### "Build tools revision X not found"

In Android Studio: Tools → SDK Manager → SDK Tools tab  
Make sure **"Android SDK Build-Tools 34"** is installed (tick the box and click Apply).

---

## 9. Project Structure

```
OfflinePal/
├── app/
│   ├── src/main/
│   │   ├── java/com/offlinepal/
│   │   │   ├── AppDatabase.kt          ← Room database (single source of truth)
│   │   │   ├── ai/
│   │   │   │   ├── AiFragment.kt       ← Chat UI
│   │   │   │   ├── ChatAdapter.kt      ← Message list adapter
│   │   │   │   ├── LocalAiEngine.kt    ← TFLite + rule-based AI engine
│   │   │   │   └── KnowledgeBase.kt    ← 50+ offline Q&A + topic passages
│   │   │   ├── notes/
│   │   │   │   ├── NoteEntity.kt       ← Room entity + DAO
│   │   │   │   ├── NoteRepository.kt
│   │   │   │   ├── NoteViewModel.kt
│   │   │   │   ├── NotesFragment.kt    ← Staggered grid list
│   │   │   │   ├── NoteAdapter.kt      ← Colour-coded cards
│   │   │   │   └── NoteEditorActivity.kt
│   │   │   ├── todo/
│   │   │   │   ├── TodoEntity.kt       ← Room entity + DAO
│   │   │   │   ├── TodoViewModel.kt
│   │   │   │   ├── TodoFragment.kt     ← Filter chips + undo delete
│   │   │   │   └── TodoAdapter.kt
│   │   │   ├── timer/
│   │   │   │   ├── TimerFragment.kt    ← Countdown + stopwatch UI
│   │   │   │   └── TimerService.kt     ← Foreground service + vibration
│   │   │   ├── quiz/
│   │   │   │   ├── QuizEntity.kt       ← Room entity + DAO
│   │   │   │   ├── QuizViewModel.kt    ← Session state + scoring
│   │   │   │   └── QuizFragment.kt     ← Flip card animation
│   │   │   └── ui/
│   │   │       ├── MainActivity.kt     ← Bottom navigation host
│   │   │       └── SplashActivity.kt
│   │   ├── res/
│   │   │   ├── layout/                 ← All XML screen layouts
│   │   │   ├── drawable/               ← Vector icons + colour circles
│   │   │   ├── values/                 ← strings, colors, themes, dimens
│   │   │   ├── menu/                   ← Navigation + editor menus
│   │   │   ├── navigation/nav_graph.xml
│   │   │   ├── animator/               ← Card flip animations
│   │   │   └── xml/                    ← Backup rules
│   │   ├── assets/
│   │   │   └── model/
│   │   │       ├── mobilebert.tflite   ← Download separately (see section 4)
│   │   │       └── README.txt
│   │   └── AndroidManifest.xml
│   └── build.gradle                    ← All dependencies declared here
├── build.gradle
├── settings.gradle
├── gradle.properties
├── download_model.sh                   ← Run once to fetch AI model
└── BUILD_GUIDE.md                      ← This file
```

---

## 10. Feature Reference

### AI Assistant — Command Reference

| What you type | What happens |
|--------------|-------------|
| `help` | Shows all commands |
| `What is the speed of light?` | Knowledge base answer |
| `calculate 15% of 240` | Returns 36 |
| `compute 123 * 456` | Returns 56088 |
| `10 km to miles` | Returns 6.21 miles |
| `72 fahrenheit to celsius` | Returns 22.2°C |
| `5 kg to lbs` | Returns 11.02 lbs |
| `summarize: [paste long text]` | Extractive summary |
| `count words [some text]` | Word count |
| `count chars [some text]` | Character count |
| Any long paragraph | Auto-summarises |

### Quiz — Scoring

- ✓ Got it right → +1 point, card marked as correct in DB
- ✗ Got it wrong → 0 points, card practice count incremented
- Session ends after all cards shown → Score displayed as percentage
- Emoji rating: 🏆 90%+ · ⭐ 70%+ · 👍 50%+ · 📚 below 50%

### Timer Presets

| Button | Duration |
|--------|---------|
| 1m | Micro break |
| 5m | Short break |
| 10m | Medium break |
| 25m | Pomodoro focus block |
| 30m | Half-hour session |
| 60m | One-hour session |

---

## 11. Permissions Explained

OfflinePal requests only two permissions:

| Permission | Why | Can be denied? |
|-----------|-----|---------------|
| `VIBRATE` | Timer alert when countdown finishes | Yes — timer still works, just no vibration |
| `FOREGROUND_SERVICE` | Keeps timer running when screen is off | No — required by Android for background timers |
| `POST_NOTIFICATIONS` | Shows timer in notification bar (Android 13+) | Yes — timer still works, notification just won't show |

**No permissions requested:**
- ❌ Internet / network access
- ❌ Camera
- ❌ Microphone
- ❌ Location
- ❌ Contacts
- ❌ Read/write external storage
- ❌ Read phone state

All user data (notes, tasks, quiz cards) is stored in the app's **private
internal storage** — other apps cannot read it without root access.

---

## Quick Reference Card

```
Build:     ./gradlew assembleDebug
APK path:  app/build/outputs/apk/debug/app-debug.apk
Min SDK:   API 24 (Android 7.0 Nougat)
Target:    API 34 (Android 14)
Model:     app/src/main/assets/model/mobilebert.tflite  (download separately)
DB:        /data/data/com.offlinepal/databases/offlinepal_database
Perms:     VIBRATE, FOREGROUND_SERVICE, POST_NOTIFICATIONS only
```

---

*OfflinePal — built with Kotlin, Room, TFLite, Material Design 3.*  
*Zero internet. Zero tracking. Zero ads. Everything stays on your device.*
