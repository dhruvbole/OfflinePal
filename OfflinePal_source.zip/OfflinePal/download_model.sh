#!/usr/bin/env bash
# download_model.sh — Run once before building OfflinePal
# Downloads the MobileBERT Q&A TFLite model (~25 MB)

set -e

DEST="app/src/main/assets/model/mobilebert.tflite"
URL="https://storage.googleapis.com/download.tensorflow.org/models/tflite/bert_qa/mobilebert_qa_squad.tflite"
ALT_URL="https://tfhub.dev/tensorflow/lite-model/mobilebert/1/metadata/1?lite-format=tflite"

echo "========================================"
echo "  OfflinePal — MobileBERT Model Setup"
echo "========================================"
echo ""

if [ -f "$DEST" ]; then
  echo "✅ Model already exists at $DEST"
  echo "   Nothing to do."
  exit 0
fi

mkdir -p "$(dirname "$DEST")"

echo "📥 Downloading MobileBERT Q&A model..."
echo "   Source: $URL"
echo ""

if command -v curl &>/dev/null; then
  curl -L --progress-bar -o "$DEST" "$URL"
elif command -v wget &>/dev/null; then
  wget --progress=bar -O "$DEST" "$URL"
else
  echo "❌ ERROR: Neither curl nor wget found."
  echo "   Please install curl or wget, then re-run this script."
  echo ""
  echo "   Or download manually from:"
  echo "   $ALT_URL"
  echo "   and save to: $DEST"
  exit 1
fi

SIZE=$(du -sh "$DEST" 2>/dev/null | cut -f1)
echo ""
echo "✅ Model downloaded successfully! ($SIZE)"
echo "   Saved to: $DEST"
echo ""
echo "You can now build the project:"
echo "  ./gradlew assembleDebug"
echo ""
